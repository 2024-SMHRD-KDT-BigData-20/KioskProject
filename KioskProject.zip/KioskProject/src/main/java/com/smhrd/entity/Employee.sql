show databases;

use sc_21K_bigdata11_p3_1;

select * from employee;